# ============================================================
# AIST 2120 — Programming Assignment 1 (PA1) Starter 
#
#
# Menu (exact choices 0–5):
#   0 Quit
#   1 Basic story stats + char_stats
#   2 Top-N words (ask N in 1–50)
#   3 Phrase search (case-insensitive) + first 3 line numbers
#   4 Random quote
#   5 Debug view (show first 20 items of freq dict)
#
# Allowed modules: random, pprint
# ============================================================

import random
import pprint

STORY_FILE = "to_build_a_fire.txt"

# -----------------------------
# PROVIDED: file reading helper (no TODO)
# -----------------------------
def read_text_file(filename):
    """Read a text file and return the entire contents.

    Parameters
    ----------
    filename : str
        Example: "to_build_a_fire.txt"

    Returns
    -------
    str or None
        • Returns the full file contents as ONE string.
        • Returns None if the file is not found.
    """
    try:
        with open(filename, "r", encoding="utf-8") as f:
            return f.read()
    except FileNotFoundError:
        print(f"ERROR: Could not find file: {filename}")
        return None

# ============================================================
# TODO 1 — get_int
# ============================================================
def get_int(prompt, low=None, high=None):
    """Read an integer from the user safely (with validation).

    Parameters
    ----------
    prompt : str
        The message shown to the user before reading input.
        Example: "Enter choice (0–5): "
    low : int or None
        If not None, the integer must be >= low.
    high : int or None
        If not None, the integer must be <= high.

    Returns
    -------
    int
        A valid integer entered by the user (within bounds if bounds are provided).

    IMPORTANT
    ---------
    You MUST return an int.
    This function should NOT print the menu choice as the "answer".
    It should NOT return None.

    Step-by-step instructions
    -------------------------
    1) Use a while-loop that repeats until you return a valid integer.
    2) Read input as a string
    3) Convert to int inside try/except:
    4) If low is not None and value < low: print range error; continue
    5) If high is not None and value > high: print range error; continue
    6) Otherwise, return value.

    Example (manual test)
    ---------------------
    If you call: get_int("Enter choice (0–5): ", 0, 5)
    and the user types: hello, 6, -1, 3
    then your function should keep reprompting and finally return 3.
    """
    # TODO: write your code here
    pass

# ============================================================
# TODO 2 — normalize_text
# ============================================================
def normalize_text(text):
    """Normalize text for word counting.

    Parameters
    ----------
    text : str
        Any input text (may contain uppercase letters and punctuation).

    Returns
    -------
    str
        A normalized version of text where:
        • all letters are lowercase
        • common punctuation is replaced with spaces
        • apostrophes (') are replaced with spaces

    Step-by-step instructions
    -------------------------
    1) Convert to lowercase using .lower()
    2) Replace punctuation with spaces.
          punct = ". , ! ? ; : \" ( ) [ ] { } < > / \\ | @ # $ % ^ & * _ + = ~ `"
	  use .replace(x, '') to replace the a given punctuation x with the empty string ''
    3) Replace apostrophes with .replace() with appropriate parameters

    Example
    -------
    Input:  "Hi! It's me, Bob."
    Output: "hi  it s me  bob "
    """
    # TODO: write your code here
    pass

# ============================================================
# TODO 3 — tokenize
# ============================================================
def tokenize(text):
    """Split normalized text into a list of tokens (words).

    Parameters
    ----------
    text : str
        Normalized text (the output of normalize_text).

    Returns
    -------
    list[str]
        A list of words (tokens). For PA1, KEEP ONLY alphabetic tokens:
        token.isalpha() must be True.

    Step-by-step instructions
    -------------------------
    1) use .split()
    2) Create an empty list words
    3) Loop through tokens, for tok in parts:if tok is alphabetic (use .isalpha), append tok to words
    4) Return words.

    Example
    -------
    Input:  "a b  c  12 dogs"
    Output: ["a", "b", "c", "dogs"]
    """
    # TODO: write your code here
    pass

# ============================================================
# TODO 4 — build_word_freq
# ============================================================
def build_word_freq(words):
    """Build a word frequency dictionary.

    Parameters
    ----------
    words : list[str]
        A list of tokens (usually from tokenize()).

    Returns
    -------
    dict[str,int]
        Dictionary mapping word -> count.
    
    Example
    -------
    Input:  ["cat", "dog", "cat"]
    Output: {"cat": 2, "dog": 1}
    """
    # TODO: write your code here
    pass

# ============================================================
# TODO 5 — top_n
# ============================================================
def top_n(freq_dict, n):
    """Return the top-N (word,count) pairs sorted by frequency.

    Parameters
    ----------
    freq_dict : dict[str,int]
        Frequency dictionary from build_word_freq().
    n : int
        Number of results to return. In this PA: 1 <= n <= 50.

    Returns
    -------
    list[tuple[str,int]]
        List of (word, count) tuples sorted by:
        1) count descending
        2) word ascending (alphabetical) for ties

    Step-by-step instructions
    -------------------------
    1) create an empty list pairs. 
    2) Iterate freq_dict, append (word, count) to pairs. 
    3) Sort:
           pairs.sort(key=TODO)
    4) Return the first n elements of pairs using list slicing

    Example
    -------
    Input:  freq_dict={"cat":3,"dog":3,"ant":5}, n=3
    Output: [("ant",5), ("cat",3), ("dog",3)]
    """
    # TODO: write your code here
    pass

# ============================================================
# PROVIDED — print_top_table (no TODO)
# ============================================================
def print_top_table(pairs):
    """Print a neat two-column table for (word, count) pairs.

    Parameters
    ----------
    pairs : list[tuple[str,int]]
        Example: [("the", 10), ("and", 7), ...]

    Returns
    -------
    None
        This function prints to the screen; it does NOT return anything.
    """
    if not pairs:
        print("No results to display.")
        return

    print("\n" + "Top Words".center(40, "-"))
    print("WORD".ljust(20) + "COUNT".rjust(10))
    print("-" * 40)
    for word, count in pairs:
        print(word.ljust(20) + str(count).rjust(10))
    print("-" * 40)

# ============================================================
# TODO 7 — char_stats
# ============================================================
def char_stats(text):
    """Count character categories in text.

    Parameters
    ----------
    text : str
        The ORIGINAL story text (not normalized).

    Returns
    -------
    dict[str,int]
        Dictionary with EXACT keys:
          • "letters"     (ch.isalpha())
          • "digits"      (ch.isdecimal())
          • "whitespace"  (ch.isspace())
          • "other"       (anything else)

    Step-by-step instructions
    -------------------------
    1) stats = {"letters":0, "digits":0, "whitespace":0, "other":0}
    2) Iterate through text and update the value in stats accordingly.
    3) return stats

    Example
    -------
    Input:  "Hi 2!\n"
    Output: {"letters":2, "digits":1, "whitespace":3, "other":1}
    """
    # TODO: write your code here
    pass

# ============================================================
# TODO 8 — count_phrase (case-insensitive only)
# ============================================================
def count_phrase(text, phrase):
    """Count occurrences of phrase in text (case-insensitive).

    Parameters
    ----------
    text : str
        Full story text.
    phrase : str
        Phrase to search for. May include spaces.

    Returns
    -------
    int
        Number of (non-overlapping) occurrences of phrase in text, case-insensitive.
        If phrase == "" (empty string), return 0.


    Example
    -------
    text   = "Fire is fire.\nFIRE!"
    phrase = "fire"
    Output: 3
    """
    # TODO: write your code here
    pass

# ============================================================
# TODO 9 — phrase_line_numbers (first 3 lines)
# ============================================================
def phrase_line_numbers(text, phrase, max_lines=3):
    """Return first line numbers where phrase appears (case-insensitive).

    Parameters
    ----------
    text : str
        Full story text.
    phrase : str
        Phrase to search for (case-insensitive).
    max_lines : int
        Maximum number of line numbers to return (for PA1 use 3).

    Returns
    -------
    list[int]
        1-based line numbers where phrase appears.
        If phrase == "" (empty string), return [].


    Example
    -------
    text = "one fish\nTwo fish\nred fish\nblue fish\n"
    phrase = "fish"
    max_lines = 3
    Output: [1, 2, 3]
    """
    # TODO: write your code here
    pass

# ============================================================
# TODO 10 — random_quote
# ============================================================
def random_quote(lines):
    """Pick a random non-empty line from the story.

    Parameters
    ----------
    lines : list[str]
        A list of lines, typically created by:
            lines = text.split("\n")

    Returns
    -------
    str
        A randomly chosen line that is not empty after stripping:
            line.strip() != ""

        If lines is empty, return "".

    Example
    -------
    lines = ["", "first line", "   ", "second line"]
    Output: either "first line" or "second line"
    """
    # TODO: write your code here
    pass

# -----------------------------
# Provided: UI helpers (no TODO)
# -----------------------------
def print_banner():
    """Print the program title banner.

    Returns
    -------
    None
    """
    print()
    print("-" * 60)
    print("AIST 2120 — PA1 Text-Analysis Mini-Toolkit".center(60))
    print("-" * 60)

def print_menu():
    """Print the menu options (0–5).

    Returns
    -------
    None
    """
    print("\nChoose an option:")
    print("  1) Show basic story stats")
    print("  2) Show Top-N words")
    print("  3) Search for a phrase (case-insensitive)")
    print("  4) Random quote")
    print("  5) Debug view (sample of frequency dict)")
    print("  0) Quit")

# ============================================================
# TODO MAIN — complete the program flow
# ============================================================
def main():
    """Run the interactive PA1 program.

    Returns
    -------
    None
        This function prints output and runs until the user chooses 0 to quit.

    What you must do
    ----------------
    Complete the TODO blocks inside main so your program works end-to-end.
    """
    # TODO MAIN-1: Print the banner
    # Hint: call print_banner()
    # print_banner()
    pass

    # TODO MAIN-2: Read the story text using read_text_file(STORY_FILE).
    # If the result is None, exit main by returning.
    # text = read_text_file(STORY_FILE)
    # if text is None:
    #     return

    # TODO MAIN-3: Build lines list for random quote & line search
    # lines = text.split("\n")

    # TODO MAIN-4: Precompute normalized text, tokens, and frequency dict ONCE:
    # norm = normalize_text(text)
    # words = tokenize(norm)
    # freq = build_word_freq(words)

    # TODO MAIN-5: Create a while-loop for the menu that runs until user chooses 0.
    #
    # Inside the loop:
    #   a) Call print_menu()
    #   b) Get menu choice using get_int("Enter choice (0–5): ", 0, 5)
    #   c) If choice == 0: print "Goodbye!" and break
    #
    # Option behaviors:
    #
    # Choice 1:
    #   - Print "Story Stats" header
    #   - Print:
    #       Characters: len(text)
    #       Lines:      len(lines)
    #       Tokens:     len(words)
    #   - Print char_stats(text) using pprint.pprint(...)
    #
    # Choice 2:
    #   - Ask n = get_int("Top how many words? (1–50): ", 1, 50)
    #   - pairs = top_n(freq, n)
    #   - print_top_table(pairs)
    #
    # Choice 3:
    #   - phrase = input("Enter a phrase to search for: ").strip()
    #   - c = count_phrase(text, phrase)
    #   - print occurrences
    #   - nums = phrase_line_numbers(text, phrase, max_lines=3)
    #   - print nums if not empty, otherwise print a friendly message
    #
    # Choice 4:
    #   - q = random_quote(lines)
    #   - print q under a "Random Quote" header
    #
    # Choice 5:
    #   - items = list(freq.items())
    #   - print(items[:20])   # first 20 pairs
    #
    # NOTE: main() should NOT return any value; it just runs and prints.
    pass

if __name__ == "__main__":
    main()
